<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="apocalypse" tilewidth="16" tileheight="16" tilecount="1000" columns="40">
 <editorsettings>
  <export target="tileset1.json" format="tsx"/>
 </editorsettings>
 <image source="tilesheet.png" trans="000000" width="640" height="400"/>
</tileset>
